namespace FractalPainting.Infrastructure.Common
{
    public class ImageSettings
    {
        public int Width { get; set; } = 100;
        public int Height { get; set; } = 100;
    }
}